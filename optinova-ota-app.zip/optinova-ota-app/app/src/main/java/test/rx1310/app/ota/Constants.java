// ! rx1310 <rx1310@inbox.ru> | Copyright (c) rx1310, 2020 | MIT License

package test.rx1310.app.ota;

public class Constants {
	
	public static final String NOVALAUNCHER_PACKAGE_NAME = "com.teslacoilsw.launcher";
	
	public static final String OTA_CHANNEL_RELEASE = "https://raw.githubusercontent.com/optinova/optinova-ota-data/master/ota_mod_release.json";
	public static final String OTA_CHANNEL_BETA = "https://raw.githubusercontent.com/optinova/optinova-ota-data/master/ota_mod_beta.json";
	public static final String OTA_CHANNEL_CLIENT = "https://raw.githubusercontent.com/optinova/optinova-ota-data/master/ota_client.json";
	
	public static final String OTA_URL_APK = "apkUrl";
	public static final String OTA_URL_CHANGELOG = "changelogUrl";
	public static final String OTA_VERSION_NAME = "versionName";
	public static final String OTA_VERSION_CODE = "versionCode";
	public static final String OTA_MESSAGE = "updateMessage";
	
}
