// ! rx1310 <rx1310@inbox.ru> | Copyright (c) rx1310, 2020 | MIT License

package test.rx1310.app.ota.utils;

import android.content.Context;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import test.rx1310.app.ota.R;
import test.rx1310.app.ota.utils.AppUtils;

public class HttpUtils {

    public static String get(Context context, String urlStr) {

        HttpURLConnection urlConnection = null;
        InputStream is = null;
        BufferedReader br = null;
        String result = null;

        try {

            URL url = new URL(urlStr);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");

            is = urlConnection.getInputStream();
            br = new BufferedReader(new InputStreamReader(is));

            StringBuilder strBuilder = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) {
                strBuilder.append(line);
            }

            result = strBuilder.toString();

        } catch (Exception e) {
            AppUtils.showToast(context, context.getString(R.string.msg_error_opti) + "42: " + e);
        } finally {

            if (br != null) {

                try {
                    br.close();
                } catch (IOException ignored) {
					AppUtils.showToast(context, context.getString(R.string.msg_error_opti) + "50: " + ignored);
				}

            }

            if (is != null) {

                try {
                    is.close();
                } catch (IOException ignored) {
					AppUtils.showToast(context, context.getString(R.string.msg_error_opti) + "60: " + ignored);
				}

            }

            if (urlConnection != null) {
                urlConnection.disconnect();
            }

        }

        return result;

    }

}
