// ! rx1310 <rx1310@inbox.ru> | Copyright (c) rx1310, 2020 | MIT License

package test.rx1310.app.ota.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.ColorInt;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AppUtils {
	
	public static String getVersionName(Context context, String packageName) {

		try {

			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(packageName, 0);

			String vn = pi.versionName;
			
			return vn;

		} catch (Exception exc) {
			exc.printStackTrace();
			return "e: getVersionName()";
		}

	}

    public static int getVersionCode(Context context, String packageName) {

		try {

			PackageManager pm = context.getPackageManager();
			PackageInfo pi = pm.getPackageInfo(packageName, 0);

			int vc = pi.versionCode;

			return vc;

		} catch (Exception exc) {
			exc.printStackTrace();
			return 0;
		}

	}
	
	public static String getAppName(Context context, String packageName) {
		
		try {
			
			PackageManager pm = context.getPackageManager();
			ApplicationInfo ai = pm.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
			
			String appName = (String) pm.getApplicationLabel(ai);
			
			return appName;
			
		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();
			return "e: getAppName();";
		}
		
	}
	
	public static boolean isAppInstalled(Context context, String packageName) {

		PackageManager packageMng = context.getPackageManager();

		try {
			packageMng.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
			return true;
		} catch(PackageManager.NameNotFoundException e) {
			return false;
		}

	}
	
	@ColorInt
	public static int getSystemAccentColor(Context context) {

		int[] attr = { android.R.attr.colorAccent };

		TypedArray arr = context.obtainStyledAttributes(android.R.style.Theme_DeviceDefault, attr);

		int clr = arr.getColor(0, Color.BLACK);
		arr.recycle();

		return clr;

	}
	
	public static void showToast(Context context, String message) {
		Toast.makeText(context, message, Toast.LENGTH_LONG).show();
	}
	
	public static boolean isNetworkAvailable(Context context) {
		
		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
		
		return networkInfo != null && networkInfo.isConnected();
		
	}
	
	public static String getDate(long ms, String customDateFormat) {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(customDateFormat);
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(ms);
		
		return dateFormat.format(calendar.getTime());
		
	}
	
	public static String getInstallDate(Context context, String packageName, boolean lastUpdateTime) {
       
        PackageManager packageMng =  context.getPackageManager();
        long installTimeInMs;

        Date installDate = null;
        String installDateString = null;

        try {
			
            PackageInfo packageInfo = packageMng.getPackageInfo(packageName, 0);
			
            if (lastUpdateTime) {
				installTimeInMs = packageInfo.lastUpdateTime;
			} else {
				installTimeInMs = packageInfo.firstInstallTime;
			}
			
            installDateString  = getDate(installTimeInMs, "dd/MM/yyyy (HH:mm:ss)");
			
        } catch (PackageManager.NameNotFoundException e) {
            installDate = new Date(0);
            installDateString = installDate.toString();
        }

        return installDateString;
		
    }
	
}
