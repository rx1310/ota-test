// ! rx1310 <rx1310@inbox.ru> | Copyright (c) rx1310, 2020 | MIT License

package test.rx1310.app.ota.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.net.Uri;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.preference.PreferenceScreen;
import android.preference.SwitchPreference;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import test.rx1310.app.ota.Constants;
import test.rx1310.app.ota.R;
import test.rx1310.app.ota.tasks.CheckUpdateTask;
import test.rx1310.app.ota.utils.AppUtils;

public class MainActivity extends PreferenceActivity {

	SimpleDateFormat mDateFormat = new SimpleDateFormat("dd/MM/yyyy (HH:mm:ss)", Locale.getDefault());
	
	String isLastCheckDate = mDateFormat.format(new Date());
	
	String isSystemVersion;
	String isModLastUpdatesCheckDate, isClientLastUpdatesCheckDate;
	Boolean isBetaChannel;
	
	PreferenceCategory categorySettings, categoryMore;
	
	Preference updateMod, updateModInfo;
	Preference updateClient, updateClientInfo;
	Preference modNotInstalled, unknownVersionInstalled;
	Preference moreTlgrm;
	
	SwitchPreference betaChannel;
	
	PreferenceScreen mPrefScr;
	SharedPreferences mSharedPrefs;
	SharedPreferences.Editor mSharedPrefsEditor;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		mSharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
		mSharedPrefsEditor = mSharedPrefs.edit();
		mPrefScr = getPreferenceManager().createPreferenceScreen(this);
		
		setPreferenceScreen(mPrefScr);
		
		isBetaChannel = mSharedPrefs.getBoolean("setting.betaChannel", false);
		isModLastUpdatesCheckDate = mSharedPrefs.getString("modLastUpdatesCheckDate", "NaN");
		isClientLastUpdatesCheckDate = mSharedPrefs.getString("clientLastUpdatesCheckDate", "NaN");
		
		// Вычисление пригодной версии системы
		if (Build.VERSION.SDK_INT < 21) {
			isSystemVersion = Build.VERSION.SDK + " (!)";
		} else {
			isSystemVersion = Build.VERSION.SDK;
		}
		
		// Пункт, который должен быть отображен
		// если не установлено вообще приложение с
		// именем пакета Nova Launcher
		modNotInstalled = new Preference(this);
		modNotInstalled.setSummary(R.string.msg_mod_not_installed);
		modNotInstalled.setEnabled(false);
		
		// Пункт "Обновить модификацию"
		updateMod = new Preference(this);
		updateMod.setTitle(R.string.pref_update_mod);
		updateMod.setSummary(R.string.pref_update_mod_summary);
		updateMod.setKey("updateMod");
		
		// Пункт, который отображает актуальную
		// информацию о модификации (посл. проверка, версия и тп.)
		updateModInfo = new Preference(this);
		updateModInfo.setSummary(String.format(getString(R.string.pref_info), isModLastUpdatesCheckDate, isModVersion(), AppUtils.getInstallDate(this, Constants.NOVALAUNCHER_PACKAGE_NAME, true)));
		updateModInfo.setEnabled(false);
		
		// Пункт, который должен быть отображен, если
		// установлен не OptiNova, а какая-то другая версия Nova Launcher
		unknownVersionInstalled = new Preference(this);
		unknownVersionInstalled.setSummary(R.string.msg_unknown_version_installed);
		unknownVersionInstalled.setEnabled(false);
		
		// Пункт "Обновить клиент"
		updateClient = new Preference(this);
		updateClient.setTitle(R.string.pref_update_client);
		updateClient.setSummary(String.format(getString(R.string.pref_update_client_summary), ""));
		updateClient.setKey("updateClient");
		
		// Аналогично пункту updateModInfo, но для клиента
		updateClientInfo = new Preference(this);
		updateClientInfo.setSummary(String.format(getString(R.string.pref_info), isClientLastUpdatesCheckDate, AppUtils.getVersionName(this, getPackageName()), AppUtils.getInstallDate(this, getPackageName(), true)));
		updateClientInfo.setEnabled(false);
		
		// Категория "Настройки клиента"
		categorySettings =  new PreferenceCategory(this);
		categorySettings.setTitle(R.string.pref_settings_category);
		
		// Переключатель канала "beta"
		betaChannel = new SwitchPreference(this);
		betaChannel.setTitle(R.string.pref_setting_beta_channel);
		betaChannel.setSummary(R.string.pref_setting_beta_channel_summary);
		betaChannel.setKey("setting.betaChannel");
		
		// Категория "Дополнительно"
		categoryMore = new PreferenceCategory(this);
		categoryMore.setTitle(R.string.pref_more_category);
		
		// Пункт для перехода в Telegram-канал модификации
		moreTlgrm = new Preference(this);
		moreTlgrm.setTitle(R.string.pref_more_telegram);
		moreTlgrm.setSummary(R.string.pref_more_telegram_summary);
		moreTlgrm.setKey("more.tlgrm");
		
		// Добавление пунктов на экран
		if (AppUtils.isAppInstalled(this, Constants.NOVALAUNCHER_PACKAGE_NAME)) {
			
			// Если приложение с нужным именем пакета установлено,
			// то будут добавлены все пункты
			mPrefScr.addPreference(updateMod);
			mPrefScr.addPreference(updateModInfo);
			
			// Если не обнаружено приложение с именем OptiNova, то отобразим
			// пункт unknownVersionInstalled
			if (!AppUtils.getAppName(this, Constants.NOVALAUNCHER_PACKAGE_NAME).contains("OptiNova")) {
				mPrefScr.addPreference(unknownVersionInstalled);
			}
			
			mPrefScr.addPreference(updateClient);
			mPrefScr.addPreference(updateClientInfo);
			mPrefScr.addPreference(categorySettings);
			mPrefScr.addPreference(betaChannel);
			mPrefScr.addPreference(categoryMore);
			
		} else {
			// Если не установлено приложение с нужным именем пакета
			mPrefScr.addPreference(modNotInstalled);
		}
		
		// Ссылка на Telegram отображается постоянно
		mPrefScr.addPreference(moreTlgrm);
		
	}
	
	public boolean onPreferenceTreeClick(PreferenceScreen mPrefScr, Preference pref) {

		switch (pref.getKey()) {

			case "updateMod":
				
				if (AppUtils.isNetworkAvailable(this)) {
					
					mSharedPrefsEditor.putString("modLastUpdatesCheckDate", isLastCheckDate);
					mSharedPrefsEditor.commit();
					
					if (isBetaChannel) {
						new CheckUpdateTask(MainActivity.this, "beta", Constants.NOVALAUNCHER_PACKAGE_NAME).execute();
					} else {
						new CheckUpdateTask(MainActivity.this, "release", Constants.NOVALAUNCHER_PACKAGE_NAME).execute();
					}
					
				} else {
					AppUtils.showToast(this, getString(R.string.msg_no_network_connection));
				}
				
				break;
				
			case "updateClient":

				if (AppUtils.isNetworkAvailable(this)) {

					mSharedPrefsEditor.putString("clientLastUpdatesCheckDate", isLastCheckDate);
					mSharedPrefsEditor.commit();

					new CheckUpdateTask(MainActivity.this, "client", getPackageName()).execute();

				} else {
					AppUtils.showToast(this, getString(R.string.msg_no_network_connection));
				}

				break;
				
			case "setting.betaChannel":
				AppUtils.showToast(this, getString(R.string.msg_switch_channel));
				recreate();
				break;
				
			case "more.tlgrm":
				startActivity(new Intent (Intent.ACTION_VIEW, Uri.parse("https://t.me/optinova")));
				break;

		}

		return super.onPreferenceTreeClick(mPrefScr, pref);

	}
	
	// Вычисляем OptiNova
	String isModVersion() {
		
		if (AppUtils.getAppName(this, Constants.NOVALAUNCHER_PACKAGE_NAME).contains("OptiNova")) {
			return AppUtils.getVersionName(this, Constants.NOVALAUNCHER_PACKAGE_NAME);
		} else {
			return this.getString(android.R.string.unknownName);
		}
		
	}
	
}
