// ! rx1310 <rx1310@inbox.ru> | Copyright (c) rx1310, 2020 | MIT License

package test.rx1310.app.ota.tasks;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import test.rx1310.app.ota.Constants;
import test.rx1310.app.ota.R;
import test.rx1310.app.ota.utils.AppUtils;
import test.rx1310.app.ota.utils.HttpUtils;

public class CheckUpdateTask extends AsyncTask<Void, Void, String> {

    private Context mContext;
	private String mChannel, mPackageName;
	
	private ProgressDialog progressDialog;
	
    public CheckUpdateTask(Context context, String isChannel, String isPackageName) {
        this.mContext = context;
		this.mChannel = isChannel;
		this.mPackageName = isPackageName;
    }

    protected void onPreExecute() {
		
		progressDialog = new ProgressDialog(mContext);
		progressDialog.setTitle(mContext.getString(R.string.msg_data_request));
		progressDialog.setCancelable(false);
		progressDialog.setMessage(mContext.getString(R.string.msg_please_wait));
		progressDialog.show();
		
    }

    @Override
    protected void onPostExecute(String result) {
		
		progressDialog.dismiss();
		
        if (!TextUtils.isEmpty(result)) {
            parseJson(result);
        }
		
    }

    private void parseJson(String result) {
		
        try {

            JSONObject obj = new JSONObject(result);
			
			String 
				versionName = obj.getString(Constants.OTA_VERSION_NAME),
				updateMessage = obj.getString(Constants.OTA_MESSAGE),
				urlApk = obj.getString(Constants.OTA_URL_APK),
				urlChangelog = obj.getString(Constants.OTA_URL_CHANGELOG);
				
			int 
				versionCode = obj.getInt(Constants.OTA_VERSION_CODE),
				versionCodeInstalled = AppUtils.getVersionCode(mContext, mPackageName);
			
			if (versionCode > versionCodeInstalled) {
				
				updateDialog(mContext, versionName, updateMessage, urlApk, urlChangelog);
				
			} else {
				AppUtils.showToast(mContext, mContext.getString(R.string.msg_installed_last_build));
			}
			
        } catch (JSONException e) {
            AppUtils.showToast(mContext, "Error: " + e);
        }
		
    }
	
	void updateDialog(final Context context, String updateVersion, String updateMessage, final String apkUrl, final String changelogUrl) {

		AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);

		alertBuilder.setTitle(updateVersion);
		alertBuilder.setMessage(updateMessage);
		alertBuilder.setPositiveButton(R.string.action_download, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface d, int i) {
				mContext.startActivity(new Intent (Intent.ACTION_VIEW, Uri.parse(apkUrl)));
			}
		});
		alertBuilder.setNegativeButton(R.string.action_changelog, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface d, int i) {
				context.startActivity(new Intent (Intent.ACTION_VIEW, Uri.parse(changelogUrl)));
			}
		});
		alertBuilder.setNeutralButton(R.string.action_copy_url, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface d, int i) {
				ClipboardManager mClipboardMng = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
				ClipData mClipData = ClipData.newPlainText(null, apkUrl);
				mClipboardMng.setPrimaryClip(mClipData);
				AppUtils.showToast(context, context.getString(R.string.msg_url_copied_to_clipboard));
			}
		});
		alertBuilder.show();

	}

    @Override
    protected String doInBackground(Void... args) {
		
		if (mChannel == "beta") {
			return HttpUtils.get(mContext, Constants.OTA_CHANNEL_BETA);
		} else if (mChannel == "release") {
			return HttpUtils.get(mContext, Constants.OTA_CHANNEL_RELEASE);
		} else if (mChannel == "client") {
			return HttpUtils.get(mContext, Constants.OTA_CHANNEL_CLIENT);
		}
		
		return HttpUtils.get(mContext, Constants.OTA_CHANNEL_RELEASE);
		
	}
	
}
